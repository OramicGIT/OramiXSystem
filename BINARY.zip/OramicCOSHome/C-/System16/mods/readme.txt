How to work:

Create a file with .cmd at the end, open this file with any text editor and make 
code for batch file, like this

@echo off
title Plugin Name

:: functions goes here...

goto :EOF

and save it to file.

Edit os.bat (not in C-\ folder, in the OS folder where your OS located) to 
make your plugin work. Have fun with it!