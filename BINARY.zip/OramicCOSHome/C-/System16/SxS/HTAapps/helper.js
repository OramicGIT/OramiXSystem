var edgePath = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
var chromePath = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
var url = 'https://copilot.microsoft.com';
var args = '--app=' + url + ' --window-size=800,600';

var fso = new ActiveXObject('Scripting.FileSystemObject');
var shell = new ActiveXObject('WScript.Shell');

function launchBrowser(browserPath, args) {
    if (fso.FileExists(browserPath)) {
        shell.Run('"' + browserPath + '" ' + args);
    } else {
        return false;
    }
    return true;
}

if (!launchBrowser(edgePath, args)) {
    launchBrowser(chromePath, args);
}
